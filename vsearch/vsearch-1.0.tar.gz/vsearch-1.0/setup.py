from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Search letters into phrase tools',
    author='fducha',
    author_email='fducha@mail.com',
    url='fducha.com',
    py_modules=['vsearch'],
)